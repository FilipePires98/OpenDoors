package pt.ua.opendoors;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class Fragment_Livestream_Temperature extends Fragment {

    private LineChart mChar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_livestream_temperature, null);

        /* Create a consumer for JSON data, starting at the beginning of the topic's log.
           The consumer group is called "my_json_consumer" and the instance is "my_consumer_instance".*/
        sendNetworkRequest1("{\"name\": \"my_consumer_instance\", \"format\": \"json\", \"auto.offset.reset\": \"earliest\"}");


        /* Subscribe the consumer to a topic */
        sendNetworkRequest2("{\"topics\":[\"jsontest\"]}");


        /* Then consume some data from a topic using the base URL in the first response. */
        String URL = "http://localhost:8082/consumers/my_json_consumer/instances/my_consumer_instance/records";
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, URL, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        JSONArray temperature = null;
                        try {
                            temperature = response.getJSONArray("temperature");

                            mChar.setDragEnabled(false);
                            mChar.setScaleEnabled(true);

                            ArrayList<Entry> yValues = new ArrayList<>();

                            for (int i = 0 ; i < temperature.length() ; i++) {
                                yValues.add(new Entry( i, (int) temperature.get(i) ));
                            }

                            Log.d("sdsdf", yValues.toString());

                            LineDataSet set1 = new LineDataSet(yValues, "Variação da Temperatura ao longo do tempo");

                            set1.setFillAlpha(110);
                            set1.setCircleColor(Color.rgb(255, 170, 0));
                            set1.setLineWidth(3f);
                            set1.setColor(Color.rgb(255, 170, 0));
                            set1.setValueTextColor(Color.rgb(0, 28, 49));
                            set1.setValueTextSize(13f);

                            ArrayList<ILineDataSet> dataSets = new ArrayList<>();
                            dataSets.add(set1);

                            LineData data = new LineData(dataSets);
                            mChar.setData(data);
                            mChar.setVisibility(View.VISIBLE);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }





                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
        requestQueue.add(objectRequest);

        return view;
    }

    private void sendNetworkRequest1(String dfp) {
        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("http://192.169.11.178:8082/consumers/temperature")
                .addConverterFactory(ScalarsConverterFactory.create());

        Retrofit retrofit = builder.build();

        DataFromPersistenceClient client = retrofit.create(DataFromPersistenceClient.class);
        Call<String> call = client.getCurrentLight(dfp);

        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, retrofit2.Response<String> response) {
                try {
                    JSONObject j = new JSONObject(response.body());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Toast.makeText(getContext(), "Deu Erro", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void sendNetworkRequest2(String dfp) {
        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("http://localhost:8082/consumers/temperature/instances/my_consumer_instance/subscription")
                .addConverterFactory(ScalarsConverterFactory.create());

        Retrofit retrofit = builder.build();

        DataFromPersistenceClient client = retrofit.create(DataFromPersistenceClient.class);
        Call<String> call = client.getCurrentLight(dfp);

        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, retrofit2.Response<String> response) {
                try {
                    JSONObject j = new JSONObject(response.body());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Toast.makeText(getContext(), "Deu Erro", Toast.LENGTH_SHORT).show();

            }
        });
    }


  }
